import React from "react";
import '../styles/App.css';
import Welcome from './Welcome';

const App = () => {
  return (
    <Welcome name="" />
  )
}


export default App;
